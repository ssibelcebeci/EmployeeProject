package CoffeMachineProject;

public class KahveMain {
    public static void main(String[] args) {

        CoffeeMachine cm =new CoffeeMachine();
        cm.kahveSecim();

    }
}
