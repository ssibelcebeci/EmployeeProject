package CoffeMachineProject;

public interface IKahve {
    void hazirla();
}
