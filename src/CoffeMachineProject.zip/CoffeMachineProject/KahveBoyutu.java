package CoffeMachineProject;

public enum KahveBoyutu {
    SMALL, MEDIUM, LARGE, XLARGE
}
